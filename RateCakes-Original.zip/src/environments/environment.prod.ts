export const environment = {
  production: true,
  urlLocal: "http://localhost:7999"
};
