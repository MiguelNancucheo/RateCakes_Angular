import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = '5_RateCakes';

  msgError: string = ""
  Cakes!: any;
  detailId: string

  constructor(private _httpService: HttpService) {
     this.msgError = ""
     this.detailId = ""

 }

 ngOnInit () {
  // this.deleteCake('637c40b7bb83529449bd1653')
  this.listCakes()

 }

 listCakes() {
  this.detailId = ""
  this.msgError = ""
  this._httpService.getCakesService()
      .subscribe( {
        next: (result) => {
          // console.log('Consulta OK : ' + JSON.stringify(result) )
          this.Cakes = result
          } ,
        error: (error) => {
          // console.log('Consulta Error: ' + JSON.stringify( error ) )
          this.msgError = "Error al consultar el dato."
        }
        }
        )
}

dataFromChildForm(eventData:Boolean) {
  if (eventData) {
    //listo de nuevo
    this.listCakes()
  }
}

dataFromChildRate(eventData: string){
  console.log(` llego eventData [${eventData}]`);
  this.detailId = eventData
  }

deleteCake( idCake:string ) {
  // console.log(` deleteCake [${idCake}]`)
  this._httpService.deleteCakeService(idCake)
      .subscribe( {
        next: (result) => {
          console.log('Elemento eliminado' )
          this.Cakes = result
          } ,
        error: (error) => {
          // console.log('Consulta Error: ' + JSON.stringify( error ) )
          this.msgError = "Error al eliminar."
        }
        } )
  }

}
