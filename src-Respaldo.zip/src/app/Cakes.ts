export interface rate {
  _id: string,
  rate: number,
  comment: string
}

export interface Cake {
  _id: string,
  name: string,
  url: string,
  rates: [rate]
}
